﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
public class back : MonoBehaviour
{

    public void changemenuscene()
    {
        SceneManager.LoadScene(0);
    }
}

