﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
public class move1 : MonoBehaviour
{

    public void changemenuscene()
    {
        SceneManager.LoadScene(1);
    }
}
